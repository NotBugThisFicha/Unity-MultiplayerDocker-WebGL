This LinuxServer folder should contains linux dedicated server files and folder like:

Server_Data
Server.x86_64
UnityPlayer.so