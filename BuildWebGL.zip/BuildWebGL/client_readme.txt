This BuildWebGL folder should contains webgl client files and folders like thats:

TemplateData
Build
index.html